 Mass Mail Dispatcher

A simple and efficient **Mass Mail Dispatcher** for sending bulk emails to a list of recipients. This tool is designed for sending newsletters, notifications, and other types of mass communication via email.

## Features
- Send emails to multiple recipients at once.
- Support for HTML and plain-text emails.
- Attach files to emails.
- Customize email content with dynamic variables.
- Logging of sent emails and errors.
- Schedule email dispatch for later delivery.
